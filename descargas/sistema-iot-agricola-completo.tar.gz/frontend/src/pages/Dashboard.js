import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { sensorAPI, alertAPI, robotAPI, systemAPI, analysisAPI } from '../api/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { 
  Thermometer, Droplets, Sun, Sprout, AlertTriangle, Bot, 
  TrendingUp, Activity, LogOut, Settings, BarChart3, Bell
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { toast } from 'sonner';
import RobotControl from '../components/RobotControl';
import AlertsPanel from '../components/AlertsPanel';
import AIAnalysisPanel from '../components/AIAnalysisPanel';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [sensorData, setSensorData] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [robotStatus, setRobotStatus] = useState(null);
  const [systemInfo, setSystemInfo] = useState(null);
  const [historicalData, setHistoricalData] = useState({});
  const [stats, setStats] = useState({
    temperature: { current: 0, status: 'normal' },
    airHumidity: { current: 0, status: 'normal' },
    soilMoisture: { current: 0, status: 'normal' },
    luminosity: { current: 0, status: 'normal' },
  });

  useEffect(() => {
    loadDashboardData();
    const interval = setInterval(loadDashboardData, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadDashboardData = async () => {
    try {
      const [sensorsRes, alertsRes, robotRes, systemRes] = await Promise.all([
        sensorAPI.getLatest({ limit: 20 }),
        alertAPI.getAlerts({ limit: 10, acknowledged: false }),
        robotAPI.getStatus(),
        systemAPI.getInfo(),
      ]);

      setSensorData(sensorsRes.data);
      setAlerts(alertsRes.data);
      setRobotStatus(robotRes.data);
      setSystemInfo(systemRes.data);

      updateStats(sensorsRes.data);
      await loadHistoricalData();
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      toast.error('Error cargando datos del dashboard');
    } finally {
      setLoading(false);
    }
  };

  const updateStats = (data) => {
    const grouped = data.reduce((acc, reading) => {
      if (!acc[reading.sensor_type]) acc[reading.sensor_type] = [];
      acc[reading.sensor_type].push(reading.value);
      return acc;
    }, {});

    const newStats = {};
    
    if (grouped.temperature?.length > 0) {
      const temp = grouped.temperature[grouped.temperature.length - 1];
      newStats.temperature = {
        current: temp,
        status: temp > 32 ? 'critical' : temp > 28 ? 'warning' : temp < 20 ? 'warning' : 'normal'
      };
    }

    if (grouped.air_humidity?.length > 0) {
      const hum = grouped.air_humidity[grouped.air_humidity.length - 1];
      newStats.airHumidity = {
        current: hum,
        status: hum < 55 ? 'warning' : hum > 85 ? 'warning' : 'normal'
      };
    }

    if (grouped.soil_moisture?.length > 0) {
      const soil = grouped.soil_moisture[grouped.soil_moisture.length - 1];
      newStats.soilMoisture = {
        current: soil,
        status: soil < 35 ? 'critical' : soil < 40 ? 'warning' : soil > 75 ? 'warning' : 'normal'
      };
    }

    if (grouped.luminosity?.length > 0) {
      const lux = grouped.luminosity[grouped.luminosity.length - 1];
      newStats.luminosity = {
        current: lux,
        status: lux > 55000 ? 'warning' : lux < 25000 ? 'warning' : 'normal'
      };
    }

    setStats(prev => ({ ...prev, ...newStats }));
  };

  const loadHistoricalData = async () => {
    try {
      const sensorTypes = ['temperature', 'air_humidity', 'soil_moisture', 'luminosity'];
      const endTime = new Date();
      const startTime = new Date(endTime.getTime() - 24 * 60 * 60 * 1000);

      const promises = sensorTypes.map(type =>
        sensorAPI.getHistory({
          sensor_type: type,
          start_time: startTime.toISOString(),
          end_time: endTime.toISOString(),
          aggregation: 'mean',
          interval: '30m',
        })
      );

      const results = await Promise.all(promises);
      const historical = {};

      results.forEach((res, idx) => {
        historical[sensorTypes[idx]] = res.data.data;
      });

      setHistoricalData(historical);
    } catch (error) {
      console.error('Failed to load historical data:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      case 'warning': return 'text-yellow-700 bg-yellow-50 border-yellow-200';
      default: return 'text-green-600 bg-green-50 border-green-200';
    }
  };

  const formatChartData = (data) => {
    if (!data || data.length === 0) return [];
    return data.map(d => ({
      time: new Date(d.timestamp).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      value: d.value
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="App min-h-screen" data-testid="dashboard-container">
      {/* Header */}
      <header className="header-nav sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-green-500 to-green-600 p-2 rounded-xl">
                <Sprout className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold" style={{ fontFamily: 'Manrope, sans-serif' }}>
                  Sistema IoT Agrícola
                </h1>
                <p className="text-xs text-gray-500">Cultivo de Mandarina</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className={alerts.length > 0 ? 'alert-badge bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}>
                  <Bell className="w-3 h-3 mr-1" />
                  {alerts.length} Alertas
                </Badge>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">{user?.full_name || user?.username}</p>
                <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
              </div>
              <Button
                data-testid="logout-button"
                variant="outline"
                size="sm"
                onClick={logout}
                className="border-red-200 text-red-600 hover:bg-red-50"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid" data-testid="dashboard-tabs">
            <TabsTrigger value="overview" data-testid="tab-overview">
              <Activity className="w-4 h-4 mr-2" />
              Resumen
            </TabsTrigger>
            <TabsTrigger value="sensors" data-testid="tab-sensors">
              <BarChart3 className="w-4 h-4 mr-2" />
              Sensores
            </TabsTrigger>
            <TabsTrigger value="alerts" data-testid="tab-alerts">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Alertas
            </TabsTrigger>
            <TabsTrigger value="robot" data-testid="tab-robot">
              <Bot className="w-4 h-4 mr-2" />
              Robot
            </TabsTrigger>
            <TabsTrigger value="analysis" data-testid="tab-analysis">
              <TrendingUp className="w-4 h-4 mr-2" />
              Análisis IA
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6 fade-in">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className={`stat-card ${getStatusColor(stats.temperature?.status)}`} data-testid="stat-temperature">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center justify-between">
                    <span className="text-sm font-medium">Temperatura</span>
                    <Thermometer className="w-5 h-5" />
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stats.temperature?.current?.toFixed(1) || '0.0'}°C</div>
                  <p className="text-xs mt-1 opacity-70">Óptimo: 23-28°C</p>
                </CardContent>
              </Card>

              <Card className={`stat-card ${getStatusColor(stats.airHumidity?.status)}`} data-testid="stat-air-humidity">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center justify-between">
                    <span className="text-sm font-medium">Humedad Aire</span>
                    <Droplets className="w-5 h-5" />
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stats.airHumidity?.current?.toFixed(1) || '0.0'}%</div>
                  <p className="text-xs mt-1 opacity-70">Óptimo: 60-80%</p>
                </CardContent>
              </Card>

              <Card className={`stat-card ${getStatusColor(stats.soilMoisture?.status)}`} data-testid="stat-soil-moisture">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center justify-between">
                    <span className="text-sm font-medium">Humedad Suelo</span>
                    <Sprout className="w-5 h-5" />
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{stats.soilMoisture?.current?.toFixed(1) || '0.0'}%</div>
                  <p className="text-xs mt-1 opacity-70">Óptimo: 40-70%</p>
                </CardContent>
              </Card>

              <Card className={`stat-card ${getStatusColor(stats.luminosity?.status)}`} data-testid="stat-luminosity">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center justify-between">
                    <span className="text-sm font-medium">Luminosidad</span>
                    <Sun className="w-5 h-5" />
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{Math.round(stats.luminosity?.current || 0)}</div>
                  <p className="text-xs mt-1 opacity-70">Óptimo: 30-50k lux</p>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="dashboard-card">
                <CardHeader>
                  <CardTitle className="text-lg">Temperatura (últimas 24h)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={formatChartData(historicalData.temperature)}>
                      <defs>
                        <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="time" style={{ fontSize: '12px' }} />
                      <YAxis style={{ fontSize: '12px' }} />
                      <Tooltip />
                      <Area type="monotone" dataKey="value" stroke="#22c55e" fillOpacity={1} fill="url(#colorTemp)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="dashboard-card">
                <CardHeader>
                  <CardTitle className="text-lg">Humedad del Suelo (últimas 24h)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={formatChartData(historicalData.soil_moisture)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="time" style={{ fontSize: '12px' }} />
                      <YAxis style={{ fontSize: '12px' }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="value" stroke="#16a34a" strokeWidth={3} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* System Status */}
            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  Estado del Sistema
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${systemInfo?.mqtt_connected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-sm">MQTT: {systemInfo?.mqtt_connected ? 'Conectado' : 'Desconectado'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${systemInfo?.influxdb_connected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-sm">InfluxDB: {systemInfo?.influxdb_connected ? 'Conectado' : 'Desconectado'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${systemInfo?.ai_enabled ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                    <span className="text-sm">IA: {systemInfo?.ai_enabled ? 'Habilitada' : 'Deshabilitada'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${robotStatus?.battery_level > 20 ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-sm">Robot: {robotStatus?.battery_level?.toFixed(0) || 0}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sensors Tab */}
          <TabsContent value="sensors" className="space-y-6 fade-in">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="dashboard-card">
                <CardHeader>
                  <CardTitle>Humedad del Aire (últimas 24h)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={formatChartData(historicalData.air_humidity)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" style={{ fontSize: '12px' }} />
                      <YAxis style={{ fontSize: '12px' }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="dashboard-card">
                <CardHeader>
                  <CardTitle>Luminosidad (últimas 24h)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={formatChartData(historicalData.luminosity)}>
                      <defs>
                        <linearGradient id="colorLux" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" style={{ fontSize: '12px' }} />
                      <YAxis style={{ fontSize: '12px' }} />
                      <Tooltip />
                      <Area type="monotone" dataKey="value" stroke="#f59e0b" fill="url(#colorLux)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Latest Readings Table */}
            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle>Lecturas Recientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-green-200">
                      <tr>
                        <th className="text-left p-3">Nodo</th>
                        <th className="text-left p-3">Sensor</th>
                        <th className="text-left p-3">Valor</th>
                        <th className="text-left p-3">Hora</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sensorData.slice(0, 10).map((reading, idx) => (
                        <tr key={idx} className="border-b border-gray-100 hover:bg-green-50 transition-colors">
                          <td className="p-3 font-medium">{reading.sensor_id}</td>
                          <td className="p-3 capitalize">{reading.sensor_type.replace('_', ' ')}</td>
                          <td className="p-3">{reading.value.toFixed(2)} {reading.unit}</td>
                          <td className="p-3 text-gray-600">
                            {new Date(reading.timestamp).toLocaleTimeString('es-ES')}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="fade-in">
            <AlertsPanel alerts={alerts} onRefresh={loadDashboardData} />
          </TabsContent>

          {/* Robot Tab */}
          <TabsContent value="robot" className="fade-in">
            <RobotControl robotStatus={robotStatus} onCommandSent={loadDashboardData} />
          </TabsContent>

          {/* Analysis Tab */}
          <TabsContent value="analysis" className="fade-in">
            <AIAnalysisPanel />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Dashboard;