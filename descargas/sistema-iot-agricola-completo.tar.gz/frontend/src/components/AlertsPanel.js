import React, { useState } from 'react';
import { alertAPI } from '../api/api';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AlertTriangle, CheckCircle, Clock, XCircle } from 'lucide-react';
import { toast } from 'sonner';

const AlertsPanel = ({ alerts, onRefresh }) => {
  const [processing, setProcessing] = useState(null);

  const handleAcknowledge = async (alertId) => {
    setProcessing(alertId);
    try {
      await alertAPI.acknowledge(alertId);
      toast.success('Alerta reconocida');
      if (onRefresh) onRefresh();
    } catch (error) {
      toast.error('Error al reconocer la alerta');
    } finally {
      setProcessing(null);
    }
  };

  const getSeverityBadge = (severity) => {
    const config = {
      critical: { color: 'bg-red-100 text-red-800 border-red-300', icon: XCircle },
      high: { color: 'bg-orange-100 text-orange-800 border-orange-300', icon: AlertTriangle },
      medium: { color: 'bg-yellow-100 text-yellow-800 border-yellow-300', icon: AlertTriangle },
      low: { color: 'bg-blue-100 text-blue-800 border-blue-300', icon: Clock },
    };
    const cfg = config[severity] || config.low;
    const Icon = cfg.icon;
    return (
      <Badge className={`${cfg.color} border`}>
        <Icon className="w-3 h-3 mr-1" />
        {severity.toUpperCase()}
      </Badge>
    );
  };

  const getAlertTypeLabel = (type) => {
    const labels = {
      high_temperature: 'Temperatura Alta',
      low_temperature: 'Temperatura Baja',
      low_soil_moisture: 'Humedad de Suelo Baja',
      high_soil_moisture: 'Humedad de Suelo Alta',
      low_air_humidity: 'Humedad de Aire Baja',
      high_luminosity: 'Luminosidad Alta',
      low_luminosity: 'Luminosidad Baja',
      robot_out_of_zone: 'Robot Fuera de Zona',
      water_stress: 'Estrés Hídrico',
      sensor_error: 'Error de Sensor',
    };
    return labels[type] || type;
  };

  return (
    <div className="space-y-6" data-testid="alerts-panel">
      {/* Summary */}
      <Card className="dashboard-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            Resumen de Alertas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600">
                {alerts.filter(a => a.severity === 'critical').length}
              </div>
              <p className="text-sm text-gray-600 mt-1">Críticas</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600">
                {alerts.filter(a => a.severity === 'high').length}
              </div>
              <p className="text-sm text-gray-600 mt-1">Altas</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-600">
                {alerts.filter(a => a.severity === 'medium').length}
              </div>
              <p className="text-sm text-gray-600 mt-1">Medias</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">
                {alerts.filter(a => a.severity === 'low').length}
              </div>
              <p className="text-sm text-gray-600 mt-1">Bajas</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alerts List */}
      <Card className="dashboard-card">
        <CardHeader>
          <CardTitle>Alertas Activas ({alerts.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {alerts.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
              <p className="text-lg font-medium text-gray-700">Sin alertas activas</p>
              <p className="text-sm text-gray-500 mt-2">Todas las condiciones están dentro de los parámetros normales</p>
            </div>
          ) : (
            <div className="space-y-3">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  data-testid={`alert-${alert.id}`}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow bg-white"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        {getSeverityBadge(alert.severity)}
                        <span className="font-semibold text-gray-800">
                          {getAlertTypeLabel(alert.alert_type)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{alert.message}</p>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        {alert.sensor_id && (
                          <span>
                            <strong>Sensor:</strong> {alert.sensor_id}
                          </span>
                        )}
                        {alert.value !== null && alert.value !== undefined && (
                          <span>
                            <strong>Valor:</strong> {alert.value.toFixed(2)}
                          </span>
                        )}
                        {alert.threshold !== null && alert.threshold !== undefined && (
                          <span>
                            <strong>Umbral:</strong> {alert.threshold.toFixed(2)}
                          </span>
                        )}
                        <span>
                          <strong>Hora:</strong> {new Date(alert.timestamp).toLocaleString('es-ES')}
                        </span>
                      </div>
                    </div>
                    <Button
                      data-testid={`acknowledge-alert-${alert.id}`}
                      onClick={() => handleAcknowledge(alert.id)}
                      disabled={processing === alert.id || alert.acknowledged === 1}
                      size="sm"
                      className="btn-primary ml-4"
                    >
                      {alert.acknowledged === 1 ? (
                        <>
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Reconocida
                        </>
                      ) : (
                        'Reconocer'
                      )}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AlertsPanel;