import React, { useState } from 'react';
import { analysisAPI } from '../api/api';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Loader2, TrendingUp, AlertCircle, Lightbulb, Brain } from 'lucide-react';
import { toast } from 'sonner';

const AIAnalysisPanel = () => {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [timeRange, setTimeRange] = useState(24);

  const runAnalysis = async () => {
    setLoading(true);
    try {
      const response = await analysisAPI.predict({
        analysis_type: 'general',
        time_range_hours: timeRange,
      });
      setAnalysis(response.data);
      toast.success('Análisis completado');
    } catch (error) {
      toast.error('Error al ejecutar el análisis');
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (risk) => {
    const colors = {
      low: 'bg-green-100 text-green-800 border-green-300',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      high: 'bg-orange-100 text-orange-800 border-orange-300',
      critical: 'bg-red-100 text-red-800 border-red-300',
    };
    return colors[risk] || colors.medium;
  };

  return (
    <div className="space-y-6" data-testid="ai-analysis-panel">
      {/* Control Panel */}
      <Card className="dashboard-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="w-5 h-5 mr-2" />
            Análisis Predictivo con IA
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Rango de Tiempo</label>
              <select
                data-testid="time-range-select"
                value={timeRange}
                onChange={(e) => setTimeRange(Number(e.target.value))}
                className="border border-gray-300 rounded-lg px-4 py-2"
                disabled={loading}
              >
                <option value={6}>6 horas</option>
                <option value={12}>12 horas</option>
                <option value={24}>24 horas</option>
                <option value={48}>48 horas</option>
                <option value={72}>72 horas</option>
              </select>
            </div>
            <div className="flex-1"></div>
            <Button
              data-testid="run-analysis-button"
              onClick={runAnalysis}
              disabled={loading}
              className="btn-primary"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Ejecutar Análisis
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <div className="space-y-6 fade-in">
          {/* Summary Card */}
          <Card className="dashboard-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Resumen del Análisis</CardTitle>
                <Badge className={`border ${getRiskColor(analysis.risk_level)}`}>
                  Riesgo: {analysis.risk_level.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">{analysis.summary}</p>
              <div className="mt-4 flex items-center space-x-2 text-xs text-gray-500">
                <span>Tipo de análisis: {analysis.analysis_type}</span>
                <span>•</span>
                <span>Generado: {new Date(analysis.timestamp).toLocaleString('es-ES')}</span>
              </div>
            </CardContent>
          </Card>

          {/* Predictions */}
          {analysis.predictions && analysis.predictions.length > 0 && (
            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Tendencias y Predicciones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analysis.predictions.map((pred, idx) => (
                    <div key={idx} className="border-l-4 border-green-500 pl-4 py-2">
                      <div className="flex items-center space-x-3 mb-1">
                        <span className="font-semibold text-gray-800 capitalize">
                          {pred.parameter?.replace('_', ' ')}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {pred.trend}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{pred.forecast}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommendations */}
          {analysis.recommendations && analysis.recommendations.length > 0 && (
            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Lightbulb className="w-5 h-5 mr-2" />
                  Recomendaciones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {analysis.recommendations.map((rec, idx) => (
                    <li key={idx} className="flex items-start space-x-3">
                      <div className="bg-green-100 rounded-full p-1.5 mt-0.5">
                        <Lightbulb className="w-4 h-4 text-green-600" />
                      </div>
                      <p className="text-sm text-gray-700 flex-1">{rec}</p>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Alerts */}
          {analysis.alerts && analysis.alerts.length > 0 && (
            <Card className="dashboard-card border-orange-200">
              <CardHeader>
                <CardTitle className="flex items-center text-lg text-orange-700">
                  <AlertCircle className="w-5 h-5 mr-2" />
                  Alertas del Análisis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {analysis.alerts.map((alert, idx) => (
                    <li key={idx} className="flex items-start space-x-3 bg-orange-50 p-3 rounded-lg">
                      <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                      <p className="text-sm text-orange-800 flex-1">{alert}</p>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Data Summary */}
          {analysis.data_summary && Object.keys(analysis.data_summary).length > 0 && (
            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle className="text-lg">Estadísticas de Datos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {Object.entries(analysis.data_summary).map(([key, value]) => {
                    if (typeof value === 'object' && value !== null) {
                      return (
                        <div key={key} className="bg-gray-50 rounded-lg p-4">
                          <p className="text-sm font-medium text-gray-600 capitalize mb-2">
                            {key.replace('_', ' ')}
                          </p>
                          <div className="space-y-1 text-xs">
                            <div className="flex justify-between">
                              <span className="text-gray-500">Mín:</span>
                              <span className="font-semibold">{value.min}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Máx:</span>
                              <span className="font-semibold">{value.max}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Prom:</span>
                              <span className="font-semibold">{value.avg}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Actual:</span>
                              <span className="font-semibold text-green-600">{value.current}</span>
                            </div>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Initial State */}
      {!analysis && !loading && (
        <Card className="dashboard-card">
          <CardContent className="py-12 text-center">
            <Brain className="w-16 h-16 mx-auto text-green-500 mb-4" />
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              Análisis Predictivo con Inteligencia Artificial
            </h3>
            <p className="text-gray-600 max-w-2xl mx-auto mb-6">
              Utiliza IA para analizar los datos históricos de tus sensores y obtener
              predicciones, tendencias y recomendaciones personalizadas para tu cultivo de mandarina.
            </p>
            <Button onClick={runAnalysis} className="btn-primary">
              <TrendingUp className="w-4 h-4 mr-2" />
              Iniciar Análisis
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AIAnalysisPanel;