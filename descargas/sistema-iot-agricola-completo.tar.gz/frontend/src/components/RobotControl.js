import React, { useState } from 'react';
import { robotAPI } from '../api/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Square, Home, 
  Navigation, Battery, MapPin, Activity
} from 'lucide-react';
import { toast } from 'sonner';

const RobotControl = ({ robotStatus, onCommandSent }) => {
  const [sending, setSending] = useState(false);

  const sendCommand = async (commandType, parameters = {}) => {
    setSending(true);
    try {
      await robotAPI.sendCommand({ command_type: commandType, parameters });
      toast.success(`Comando "${commandType}" enviado al robot`);
      if (onCommandSent) onCommandSent();
    } catch (error) {
      toast.error('Error enviando comando al robot');
    } finally {
      setSending(false);
    }
  };

  const getBatteryColor = (level) => {
    if (level > 60) return 'text-green-600 bg-green-50';
    if (level > 30) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getStatusColor = (status) => {
    const statusMap = {
      idle: 'bg-gray-500',
      moving: 'bg-green-500',
      patrolling: 'bg-blue-500',
      charging: 'bg-yellow-500',
      error: 'bg-red-500',
    };
    return statusMap[status] || 'bg-gray-500';
  };

  return (
    <div className="space-y-6" data-testid="robot-control-panel">
      {/* Status Card */}
      <Card className="dashboard-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="w-5 h-5 mr-2" />
            Estado del Robot
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-center space-x-3">
              <div className={`w-4 h-4 rounded-full ${getStatusColor(robotStatus?.status)} animate-pulse`}></div>
              <div>
                <p className="text-xs text-gray-500">Estado</p>
                <p className="text-sm font-semibold capitalize">{robotStatus?.status || 'Desconocido'}</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Battery className={`w-5 h-5 ${getBatteryColor(robotStatus?.battery_level || 0).split(' ')[0]}`} />
              <div>
                <p className="text-xs text-gray-500">Batería</p>
                <p className="text-sm font-semibold">{robotStatus?.battery_level?.toFixed(0) || 0}%</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <MapPin className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-xs text-gray-500">Posición</p>
                <p className="text-sm font-semibold">
                  {robotStatus?.position?.lat?.toFixed(4) || '0.0000'}, {robotStatus?.position?.lon?.toFixed(4) || '0.0000'}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Navigation className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-xs text-gray-500">Rumbo</p>
                <p className="text-sm font-semibold">{robotStatus?.heading?.toFixed(0) || 0}°</p>
              </div>
            </div>
          </div>

          {robotStatus?.current_task && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm">
                <span className="font-semibold text-blue-800">Tarea actual:</span>
                <span className="ml-2 text-blue-700">{robotStatus.current_task}</span>
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Manual Control */}
        <Card className="dashboard-card">
          <CardHeader>
            <CardTitle className="text-lg">Control Manual</CardTitle>
            <CardDescription>Controla los movimientos básicos del robot</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center space-y-4">
              {/* Forward */}
              <Button
                data-testid="robot-move-forward"
                onClick={() => sendCommand('move_forward')}
                disabled={sending}
                className="robot-control-btn w-16 h-16 rounded-xl"
              >
                <ArrowUp className="w-6 h-6" />
              </Button>

              {/* Left, Stop, Right */}
              <div className="flex items-center space-x-4">
                <Button
                  data-testid="robot-turn-left"
                  onClick={() => sendCommand('turn_left')}
                  disabled={sending}
                  className="robot-control-btn w-16 h-16 rounded-xl"
                >
                  <ArrowLeft className="w-6 h-6" />
                </Button>
                <Button
                  data-testid="robot-stop"
                  onClick={() => sendCommand('stop')}
                  disabled={sending}
                  className="robot-control-btn w-16 h-16 rounded-xl bg-red-50 hover:bg-red-100 border-red-200"
                >
                  <Square className="w-6 h-6 text-red-600" />
                </Button>
                <Button
                  data-testid="robot-turn-right"
                  onClick={() => sendCommand('turn_right')}
                  disabled={sending}
                  className="robot-control-btn w-16 h-16 rounded-xl"
                >
                  <ArrowRight className="w-6 h-6" />
                </Button>
              </div>

              {/* Backward */}
              <Button
                data-testid="robot-move-backward"
                onClick={() => sendCommand('move_backward')}
                disabled={sending}
                className="robot-control-btn w-16 h-16 rounded-xl"
              >
                <ArrowDown className="w-6 h-6" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Automated Commands */}
        <Card className="dashboard-card">
          <CardHeader>
            <CardTitle className="text-lg">Comandos Automatizados</CardTitle>
            <CardDescription>Tareas predefinidas y rutas</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              data-testid="robot-return-home"
              onClick={() => sendCommand('return_home')}
              disabled={sending}
              className="w-full btn-primary flex items-center justify-center"
            >
              <Home className="w-5 h-5 mr-2" />
              Regresar a Base
            </Button>

            <Button
              data-testid="robot-start-patrol"
              onClick={() => sendCommand('start_patrol')}
              disabled={sending}
              className="w-full btn-primary flex items-center justify-center"
            >
              <Navigation className="w-5 h-5 mr-2" />
              Iniciar Patrullaje
            </Button>

            <Button
              data-testid="robot-stop-patrol"
              onClick={() => sendCommand('stop_patrol')}
              disabled={sending}
              variant="outline"
              className="w-full flex items-center justify-center border-red-200 text-red-600 hover:bg-red-50"
            >
              <Square className="w-5 h-5 mr-2" />
              Detener Patrullaje
            </Button>

            <div className="pt-3 border-t border-gray-200">
              <p className="text-xs text-gray-500 text-center">
                Posición GPS: {robotStatus?.position?.lat?.toFixed(6) || '0.000000'}, {robotStatus?.position?.lon?.toFixed(6) || '0.000000'}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Map Placeholder */}
      <Card className="dashboard-card">
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            <MapPin className="w-5 h-5 mr-2" />
            Mapa de Posición
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-8 text-center border-2 border-dashed border-green-300">
            <MapPin className="w-12 h-12 mx-auto text-green-600 mb-3" />
            <p className="text-sm text-green-800 font-medium">
              Visualización de mapa GPS
            </p>
            <p className="text-xs text-green-600 mt-1">
              Posición actual: Lat {robotStatus?.position?.lat?.toFixed(6) || '0.000000'}, Lon {robotStatus?.position?.lon?.toFixed(6) || '0.000000'}
            </p>
            <p className="text-xs text-gray-500 mt-3">
              Integrar con Leaflet/OpenStreetMap para visualización completa
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RobotControl;