import axios from 'axios';

const API_URL = process.env.REACT_APP_BACKEND_URL;

const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  getCurrentUser: () => api.get('/auth/me'),
};

export const sensorAPI = {
  getLatest: (params) => api.get('/sensors/latest', { params }),
  getHistory: (data) => api.post('/sensors/history', data),
};

export const alertAPI = {
  getAlerts: (params) => api.get('/alerts', { params }),
  acknowledge: (alertId) => api.post('/alerts/acknowledge', { alert_id: alertId }),
};

export const robotAPI = {
  getStatus: () => api.get('/robot/status'),
  sendCommand: (command) => api.post('/robot/control', command),
  getCommands: (params) => api.get('/robot/commands', { params }),
};

export const analysisAPI = {
  predict: (data) => api.post('/analysis/predict', data),
};

export const systemAPI = {
  getInfo: () => api.get('/system/info'),
};

export default api;